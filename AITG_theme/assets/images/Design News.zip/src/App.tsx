export default function App() {
  // Redirect to index.html
  window.location.href = '/index.html';
  
  return (
    <div style={{ 
      display: 'flex', 
      alignItems: 'center', 
      justifyContent: 'center', 
      minHeight: '100vh',
      fontFamily: 'system-ui, -apple-system, sans-serif'
    }}>
      <p>Redirecting to index.html...</p>
    </div>
  );
}
