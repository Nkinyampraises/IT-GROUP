import { NewsArticle } from '../types/news';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface NewsDetailProps {
  article: NewsArticle;
  onBack: () => void;
}

export function NewsDetail({ article, onBack }: NewsDetailProps) {
  return (
    <div className="container py-5">
      <button 
        className="btn btn-link mb-4 ps-0"
        onClick={onBack}
        style={{ 
          textDecoration: 'none', 
          color: '#0066FF',
          fontSize: '16px'
        }}
      >
        ← Back to Articles
      </button>
      
      <div className="row justify-content-center">
        <div className="col-lg-8">
          <div className="card shadow-sm" style={{ border: 'none', borderRadius: '8px' }}>
            <ImageWithFallback 
              src={article.image} 
              alt={article.title}
              className="card-img-top"
              style={{ 
                width: '100%', 
                height: '400px', 
                objectFit: 'cover',
                borderRadius: '8px 8px 0 0'
              }}
            />
            <div className="card-body" style={{ padding: '40px' }}>
              <div className="d-flex align-items-center gap-3 mb-3">
                <div className="d-flex align-items-center gap-2">
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path d="M12.6667 3H12V1.66667H10.6667V3H5.33333V1.66667H4V3H3.33333C2.59333 3 2.00667 3.6 2.00667 4.33333L2 13.6667C2 14.4 2.59333 15 3.33333 15H12.6667C13.4 15 14 14.4 14 13.6667V4.33333C14 3.6 13.4 3 12.6667 3ZM12.6667 13.6667H3.33333V6.66667H12.6667V13.6667Z" fill="#0066FF"/>
                  </svg>
                  <span style={{ fontSize: '14px', color: '#0066FF' }}>{article.date}</span>
                </div>
                <span style={{ color: '#ccc' }}>|</span>
                <div className="d-flex align-items-center gap-2">
                  <span style={{ fontSize: '14px', color: '#666' }}>By {article.author}</span>
                </div>
              </div>

              <h1 className="mb-3" style={{ color: '#1a1a1a', fontSize: '32px' }}>
                {article.title}
              </h1>

              <div className="mb-4">
                {article.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="badge me-2"
                    style={{
                      backgroundColor: '#e3f2fd',
                      color: '#0066FF',
                      padding: '6px 12px',
                      borderRadius: '4px'
                    }}
                  >
                    {tag}
                  </span>
                ))}
              </div>

              <div 
                style={{ 
                  fontSize: '16px', 
                  lineHeight: '1.8', 
                  color: '#444',
                  whiteSpace: 'pre-line'
                }}
              >
                {article.content}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
