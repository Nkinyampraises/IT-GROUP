import { NewsArticle } from '../types/news';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface NewsCardProps {
  article: NewsArticle;
  onClick: () => void;
}

export function NewsCard({ article, onClick }: NewsCardProps) {
  return (
    <div 
      className="card h-100 shadow-sm" 
      onClick={onClick}
      style={{ cursor: 'pointer', border: 'none', borderRadius: '8px', overflow: 'hidden' }}
    >
      <div style={{ position: 'relative', overflow: 'hidden', height: '200px' }}>
        <ImageWithFallback 
          src={article.image} 
          alt={article.title}
          className="card-img-top"
          style={{ width: '100%', height: '100%', objectFit: 'cover' }}
        />
        <div 
          className="badge position-absolute"
          style={{
            bottom: '16px',
            left: '16px',
            backgroundColor: '#0066FF',
            color: 'white',
            padding: '6px 12px',
            borderRadius: '4px'
          }}
        >
          {article.category}
        </div>
      </div>
      <div className="card-body" style={{ padding: '20px' }}>
        <h5 className="card-title mb-2" style={{ color: '#1a1a1a' }}>
          {article.title}
        </h5>
        <p className="card-text text-muted mb-3" style={{ fontSize: '14px' }}>
          {article.excerpt}
        </p>
        <div className="d-flex align-items-center justify-content-between">
          <div className="d-flex align-items-center gap-2">
            <div 
              style={{
                width: '24px',
                height: '24px',
                backgroundColor: '#e0e0e0',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                <path d="M6 6C7.1 6 8 5.1 8 4C8 2.9 7.1 2 6 2C4.9 2 4 2.9 4 4C4 5.1 4.9 6 6 6ZM6 7C4.67 7 2 7.67 2 9V10H10V9C10 7.67 7.33 7 6 7Z" fill="#666"/>
              </svg>
            </div>
            <span style={{ fontSize: '13px', color: '#666' }}>{article.author}</span>
          </div>
          <div className="d-flex align-items-center gap-2">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M11.0833 2.33334H10.5V1.16667H9.33333V2.33334H4.66667V1.16667H3.5V2.33334H2.91667C2.275 2.33334 1.75583 2.85834 1.75583 3.5L1.75 11.0833C1.75 11.725 2.275 12.25 2.91667 12.25H11.0833C11.725 12.25 12.25 11.725 12.25 11.0833V3.5C12.25 2.85834 11.725 2.33334 11.0833 2.33334ZM11.0833 11.0833H2.91667V5.83334H11.0833V11.0833Z" fill="#0066FF"/>
            </svg>
            <span style={{ fontSize: '13px', color: '#0066FF' }}>{article.date}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
