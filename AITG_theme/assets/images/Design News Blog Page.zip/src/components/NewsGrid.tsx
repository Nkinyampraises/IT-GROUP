import { NewsArticle } from '../types/news';
import { articles } from '../data/articles';
import { NewsCard } from './NewsCard';

interface NewsGridProps {
  onArticleClick: (article: NewsArticle) => void;
}

export function NewsGrid({ onArticleClick }: NewsGridProps) {
  return (
    <div className="container py-5">
      <div className="row g-4">
        {articles.map((article) => (
          <div key={article.id} className="col-md-6 col-lg-4">
            <NewsCard article={article} onClick={() => onArticleClick(article)} />
          </div>
        ))}
      </div>
    </div>
  );
}
