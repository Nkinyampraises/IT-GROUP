import { NewsArticle } from '../types/news';

export const articles: NewsArticle[] = [
  {
    id: 1,
    category: 'Financial Management',
    title: '10 Strategies for Business Growth in...',
    excerpt: 'Learn how successful entrepreneurs and visionaries craft a winning...',
    content: `When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy.

    It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum to make a type specimen book.

    When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.`,
    image: 'https://images.unsplash.com/photo-1709715357520-5e1047a2b691?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHRlYW0lMjBtZWV0aW5nfGVufDF8fHx8MTc2NDczNDU5M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    author: 'Rosalina William',
    date: 'Mar 07, 2025',
    tags: ['Financial Management', 'Business']
  },
  {
    id: 2,
    category: 'Financial Management',
    title: 'Navigating Tax Season: Tips for Small...',
    excerpt: 'Learn how successful entrepreneurs leverage technology to gain a...',
    content: `When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy.

    It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum to make a type specimen book.

    When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.`,
    image: 'https://images.unsplash.com/photo-1680459575585-390ed5cfcae0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvZmZpY2UlMjBjb2xsYWJvcmF0aW9ufGVufDF8fHx8MTc2NDc2NzExOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    author: 'Rosalina William',
    date: 'Mar 07, 2025',
    tags: ['Financial Management', 'Startups']
  },
  {
    id: 3,
    category: 'Enterprise solutions',
    title: 'The Power of Data Analytics in Business...',
    excerpt: 'Explore the significance of innovation in modern business...',
    content: `When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy.

    It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum to make a type specimen book.

    When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.`,
    image: 'https://images.unsplash.com/photo-1748609160056-7b95f30041f0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXRhJTIwYW5hbHl0aWNzJTIwd29ya3NwYWNlfGVufDF8fHx8MTc2NDc1Mjg5MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    author: 'Rosalina William',
    date: 'Mar 07, 2025',
    tags: ['Enterprise solutions', 'Analytics']
  },
  {
    id: 4,
    category: 'Enterprise solutions',
    title: 'How to Create a Winning Marketing Plan',
    excerpt: 'Discover strategies for achieving personal and professional success as an...',
    content: `When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy.

    It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum to make a type specimen book.

    When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.`,
    image: 'https://images.unsplash.com/photo-1758873269811-4e62e346b4b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHN0cmF0ZWd5JTIwcGxhbm5pbmd8ZW58MXx8fHwxNzY0ODEwNTc1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    author: 'Rosalina William',
    date: 'Mar 07, 2025',
    tags: ['Enterprise solutions', 'Marketing']
  },
  {
    id: 5,
    category: 'Technology Trends',
    title: 'Digital Transformation: Future of Work',
    excerpt: 'Understanding the impact of digital transformation on modern workplaces...',
    content: `When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy.

    It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum to make a type specimen book.

    When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.`,
    image: 'https://images.unsplash.com/photo-1758520144426-edf40a58f299?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBvZmZpY2UlMjBkaXNjdXNzaW9ufGVufDF8fHx8MTc2NDgzNzY1NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    author: 'Rosalina William',
    date: 'Mar 07, 2025',
    tags: ['Technology Trends', 'Digital']
  },
  {
    id: 6,
    category: 'Leadership',
    title: 'Building Effective Teams in Remote Work',
    excerpt: 'Best practices for managing and leading distributed teams successfully...',
    content: `When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy.

    It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum to make a type specimen book.

    When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.`,
    image: 'https://images.unsplash.com/photo-1630487656049-6db93a53a7e9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3Jwb3JhdGUlMjB0ZWFtd29ya3xlbnwxfHx8fDE3NjQ4Mzc2NTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    author: 'Rosalina William',
    date: 'Mar 07, 2025',
    tags: ['Leadership', 'Remote Work']
  }
];
