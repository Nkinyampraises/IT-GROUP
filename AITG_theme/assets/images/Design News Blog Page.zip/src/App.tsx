import { useState } from 'react';
import { NewsGrid } from './components/NewsGrid';
import { NewsDetail } from './components/NewsDetail';
import { NewsArticle } from './types/news';
import './styles/bootstrap.css';

export default function App() {
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);

  const handleArticleClick = (article: NewsArticle) => {
    setSelectedArticle(article);
  };

  const handleBackToGrid = () => {
    setSelectedArticle(null);
  };

  return (
    <div className="min-vh-100" style={{ backgroundColor: '#f8f9fa' }}>
      {selectedArticle ? (
        <NewsDetail article={selectedArticle} onBack={handleBackToGrid} />
      ) : (
        <NewsGrid onArticleClick={handleArticleClick} />
      )}
    </div>
  );
}
