import { useState } from 'react';
import './styles/style.css';

export default function App() {
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const articles = [
    {
      id: 1,
      category: 'Financial Management',
      title: '10 Strategies for Business Growth in 2025',
      excerpt: 'Learn how successful entrepreneurs and visionaries craft a winning strategy for sustainable business growth...',
      content: 'When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy.\n\nIt was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum to make a type specimen book.\n\nWhen an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.',
      image: 'https://images.unsplash.com/photo-1709715357520-5e1047a2b691?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHRlYW0lMjBtZWV0aW5nfGVufDF8fHx8MTc2NDczNDU5M3ww&ixlib=rb-4.1.0&q=80&w=1080',
      author: 'Rosalina William',
      date: 'Mar 07, 2025'
    },
    {
      id: 2,
      category: 'Financial Management',
      title: 'Navigating Tax Season: Tips for Small Business',
      excerpt: 'Learn how successful entrepreneurs leverage technology to gain a competitive advantage in the market...',
      content: 'When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy.\n\nIt was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum to make a type specimen book.\n\nWhen an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.',
      image: 'https://images.unsplash.com/photo-1680459575585-390ed5cfcae0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvZmZpY2UlMjBjb2xsYWJvcmF0aW9ufGVufDF8fHx8MTc2NDc2NzExOXww&ixlib=rb-4.1.0&q=80&w=1080',
      author: 'Rosalina William',
      date: 'Mar 07, 2025'
    },
    {
      id: 3,
      category: 'Enterprise solutions',
      title: 'The Power of Data Analytics in Business',
      excerpt: 'Explore the significance of innovation in modern business and how data drives decision making...',
      content: 'When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy.\n\nIt was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum to make a type specimen book.\n\nWhen an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.',
      image: 'https://images.unsplash.com/photo-1748609160056-7b95f30041f0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXRhJTIwYW5hbHl0aWNzJTIwd29ya3NwYWNlfGVufDF8fHx8MTc2NDc1Mjg5MHww&ixlib=rb-4.1.0&q=80&w=1080',
      author: 'Rosalina William',
      date: 'Mar 07, 2025'
    },
    {
      id: 4,
      category: 'Enterprise solutions',
      title: 'How to Create a Winning Marketing Plan',
      excerpt: 'Discover strategies for achieving personal and professional success as an entrepreneur in digital age...',
      content: 'When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy.\n\nIt was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum to make a type specimen book.\n\nWhen an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.',
      image: 'https://images.unsplash.com/photo-1758873269811-4e62e346b4b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHN0cmF0ZWd5JTIwcGxhbm5pbmd8ZW58MXx8fHwxNzY0ODEwNTc1fDA&ixlib=rb-4.1.0&q=80&w=1080',
      author: 'Rosalina William',
      date: 'Mar 07, 2025'
    },
    {
      id: 5,
      category: 'Technology Trends',
      title: 'Digital Transformation: Future of Work',
      excerpt: 'Understanding the impact of digital transformation on modern workplaces and remote collaboration...',
      content: 'When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy.\n\nIt was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum to make a type specimen book.\n\nWhen an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.',
      image: 'https://images.unsplash.com/photo-1758520144426-edf40a58f299?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBvZmZpY2UlMjBkaXNjdXNzaW9ufGVufDF8fHx8MTc2NDgzNzY1NXww&ixlib=rb-4.1.0&q=80&w=1080',
      author: 'Rosalina William',
      date: 'Mar 07, 2025'
    },
    {
      id: 6,
      category: 'Leadership',
      title: 'Building Effective Teams in Remote Work',
      excerpt: 'Best practices for managing and leading distributed teams successfully in the modern workplace...',
      content: 'When an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. Although we offer the one-stop solution to cane up with a right link building strategy.\n\nIt was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum to make a type specimen book.\n\nWhen an unknown printer took a galley of type and scrambled make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.',
      image: 'https://images.unsplash.com/photo-1630487656049-6db93a53a7e9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3Jwb3JhdGUlMjB0ZWFtd29ya3xlbnwxfHx8fDE3NjQ4Mzc2NTZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      author: 'Rosalina William',
      date: 'Mar 07, 2025'
    }
  ];

  const selectedArticle = articles.find(a => a.id === selectedId);

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#f8f9fa' }}>
      {/* Grid View */}
      {!selectedArticle && (
        <div className="container py-5">
          <div className="row">
            {articles.map((article) => (
              <div key={article.id} className="col-lg-4 col-md-6 mb-4">
                <div className="card h-100" onClick={() => setSelectedId(article.id)} style={{ cursor: 'pointer' }}>
                  <div className="image-wrapper">
                    <img src={article.image} className="card-img-top" alt={article.title} />
                    <span className="badge-category">{article.category}</span>
                  </div>
                  <div className="card-body">
                    <h5 className="card-title">{article.title}</h5>
                    <p className="card-text">{article.excerpt}</p>
                    <div className="card-footer-custom">
                      <div className="author-info">
                        <div className="author-avatar">
                          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                            <path d="M6 6C7.1 6 8 5.1 8 4C8 2.9 7.1 2 6 2C4.9 2 4 2.9 4 4C4 5.1 4.9 6 6 6ZM6 7C4.67 7 2 7.67 2 9V10H10V9C10 7.67 7.33 7 6 7Z" fill="#666"/>
                          </svg>
                        </div>
                        <span className="author-name">{article.author}</span>
                      </div>
                      <div className="date-info">
                        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                          <path d="M11.0833 2.33334H10.5V1.16667H9.33333V2.33334H4.66667V1.16667H3.5V2.33334H2.91667C2.275 2.33334 1.75583 2.85834 1.75583 3.5L1.75 11.0833C1.75 11.725 2.275 12.25 2.91667 12.25H11.0833C11.725 12.25 12.25 11.725 12.25 11.0833V3.5C12.25 2.85834 11.725 2.33334 11.0833 2.33334ZM11.0833 11.0833H2.91667V5.83334H11.0833V11.0833Z" fill="#0066FF"/>
                        </svg>
                        <span className="date-text">{article.date}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Detail View */}
      {selectedArticle && (
        <div className="container py-5">
          <button className="btn-back" onClick={() => setSelectedId(null)}>
            ← Back to Articles
          </button>
          
          <div className="row justify-content-center mt-4">
            <div className="col-lg-8">
              <div className="card detail-card">
                <img src={selectedArticle.image} className="card-img-top detail-image" alt={selectedArticle.title} />
                <div className="card-body detail-body">
                  <div className="detail-meta">
                    <div className="meta-item">
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                        <path d="M12.6667 3H12V1.66667H10.6667V3H5.33333V1.66667H4V3H3.33333C2.59333 3 2.00667 3.6 2.00667 4.33333L2 13.6667C2 14.4 2.59333 15 3.33333 15H12.6667C13.4 15 14 14.4 14 13.6667V4.33333C14 3.6 13.4 3 12.6667 3ZM12.6667 13.6667H3.33333V6.66667H12.6667V13.6667Z" fill="#0066FF"/>
                      </svg>
                      <span style={{ color: '#0066FF' }}>{selectedArticle.date}</span>
                    </div>
                    <span style={{ color: '#ccc', margin: '0 8px' }}>|</span>
                    <div className="meta-item">
                      <span style={{ color: '#666' }}>By {selectedArticle.author}</span>
                    </div>
                  </div>

                  <h1 className="detail-title">{selectedArticle.title}</h1>

                  <div className="mb-4">
                    <span className="badge-tag">{selectedArticle.category}</span>
                  </div>

                  <div className="detail-content">
                    {selectedArticle.content}
                  </div>

                  {/* Related Articles */}
                  <div className="related-articles">
                    <h4>Read More Articles</h4>
                    <div className="row">
                      {articles.filter(a => a.id !== selectedArticle.id).slice(0, 3).map((article) => (
                        <div key={article.id} className="col-md-4 mb-3">
                          <div className="related-card" onClick={() => setSelectedId(article.id)}>
                            <img src={article.image} alt={article.title} />
                            <h6>{article.title}</h6>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
